function calc(json){
  var parsedJSON = JSON.parse(json);
  if ('expr' in parsedJSON) {
    parsedJSON.number = calc(JSON.stringify(parsedJSON.expr));
  }
  return eval(parsedJSON.operation + '(parsedJSON.number)');
}

function add(parsedNumber) {
  return stack[stack.length - 1] + parsedNumber;
}

function subtract(parsedNumber) {
  return stack[stack.length - 1] - parsedNumber;
}

function push(parsedNumber) {
  stack.push(parsedNumber);
}

function pop() {
  return stack.pop();
}

function print() {
  var i = stack.length;
  var printString = '';
  for (var j = i-1; j >= 0; j--) {
    printString += ' ' + stack[j] + ' ';
  }
  console.log(printString);
}

var stack = [0];
calc('{"number" : 5, "operation" : "add"}');
calc('{"expr": {"number" : 2, "operation" : "subtract"}, "operation" : "push"}');
calc('{"expr": {"number" : 19, "operation" :  "add"}, "operation" :  "push"}');
calc('{"operation" :  "pop"}');
calc('{"operation" :  "print"}');
calc('{"expr": {"expr": {"operation" :  "pop"}, "operation" :  "add"}, "operation" : "push"}');
calc('{"operation" :  "print"}');
calc('{"operation" :  "pop"}');
calc('{"operation" :  "pop"}');
calc('{"operation" :  "pop"}');
