function calc(json){
  var parsedJSON = JSON.parse(json);
  if ('expr' in parsedJSON) {
    parsedJSON.number = calc(JSON.stringify(parsedJSON.expr));
  }
  return eval(parsedJSON.operation + '(parsedJSON.number)');
}

function add(parsedNumber) {
  runningTotal += parsedNumber;
  return runningTotal;
}

function subtract(parsedNumber) {
  runningTotal -= parsedNumber;
  return runningTotal;
}

var runningTotal = 0;
console.log(calc('{"number" : 5, "operation" : "add"}'));
console.log(calc('{"number" : 2, "operation" :  "subtract"}'));
console.log(calc('{"number" : 19, "operation" : "add"}'));
console.log(calc('{"expr": {"number" : 15, "operation" : "subtract"}, "operation" : "add"}'));
console.log(calc('{"expr": {"expr": {"number" : 3, "operation" :  "add"}, "operation" : "add"}, "operation" : "subtract"}'));
