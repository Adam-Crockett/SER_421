
Project: Lab 1 SER 421 Gary ReadMe.txt
Author: Pedram Sharif 
Date Last Modified: October 20, 2016

Activity 1: 

For Activity 1 I combined parts A, B and C into one .html file. I could not get DateTime to look any different than a text input. I’m not sure if DateTime works in some browsers, but not in chrome which I used to check it in. DateTime-local did work though. 

Activity 2: 

I did not see a connection type for “https://search.yahoo.com/“ in the response headers. I did see “keep alive” in the request headers using firebug. So I put that it used persistent connections. 

Activity 3: 

I created three separate .js files for activity A, B, and C. The solution for Part B will work for part A, but not for part C. Part C will not work for part A, and B because of the different functionality of the add and subtract operations. 