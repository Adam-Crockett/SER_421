Pedram Sharif
Anthony Kowal

SER 421B Fall 2016 
Lab 6

*Both extra credit problems have been done.
